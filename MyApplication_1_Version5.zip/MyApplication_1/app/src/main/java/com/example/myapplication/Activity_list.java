package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.lang.ref.Reference;
import java.util.ArrayList;
//allows user to add a date/time schedule to the meeting ID and also displays all the chosen time and dates
public class Activity_list extends AppCompatActivity {

    public static ArrayList<SampleData> timeDataList;
    public String meeting_id;
    public String meeting_name;
    private Myadapter simpleadapter;
    public static int counter=0;

    private Button finisher;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        final Bundle bundle = getIntent().getExtras();

        meeting_id= bundle.getString("meeting_id");
        meeting_name= bundle.getString("meeting_name");

        this.InitializeTimeData();


        finisher = findViewById(R.id.finish);
        ListView listView = (ListView)findViewById(R.id.listView);

        //enables the application to create a variable number of listviews
        //depending on how many date/time schedules were added by the user
        simpleadapter = new Myadapter(this,timeDataList);

        listView.setAdapter(simpleadapter);


    }

    //Initializes a new array list of sample data (a class created by us)
    //this array list is send to myadapter class which will dynamically add list views of the schedules created
    private void InitializeTimeData() {
        timeDataList = new ArrayList<SampleData>();

    }

    //Once the choose date and time button is clicked, takes you to the Calendar_activity page
    public void buttonClick(View view)
    {
        Intent intent = new Intent(Activity_list.this, Calendar_activity.class);
        intent.putExtra("meeting_id", meeting_id);
        intent.putExtra("meeting_name", meeting_name);
        startActivityForResult(intent,0);
    }

    //Once the finish button is clicked it takes you back to the first page
    public void confirmClick(View view)
    {
        Intent intent_main = new Intent(Activity_list.this, First.class); // Your list's Intent
        intent_main.setFlags(intent_main.getFlags() | Intent.FLAG_ACTIVITY_NO_HISTORY); // Adds the FLAG_ACTIVITY_NO_HISTORY flag
        startActivity(intent_main);
        finish();
    }
    @Override
    protected void onResume() {
        super.onResume();
        simpleadapter.notifyDataSetChanged();
    }


    }


